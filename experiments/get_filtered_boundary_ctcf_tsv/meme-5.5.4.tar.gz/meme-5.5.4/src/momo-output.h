#include "array-list.h"
#include "momo.h"
#include "alphabet.h"

/**********************************************************************
 * This function saves the MOMO results as a set of files in a directory:
 *********************************************************************/
void print_momo_results(int argc, char **argv, MOMO_OPTIONS_T options, SUMMARY_T);

